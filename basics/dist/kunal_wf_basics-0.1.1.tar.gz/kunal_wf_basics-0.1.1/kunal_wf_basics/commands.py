import typer
from kunal_wf_basics.processing_functions import  upper_case
# from kunal_wf_basics import processing_functions as functions

app = typer.Typer()

@app.command()
def basic(input_file: str, output_file: str = None):
   
    upper_case(input_file, output_file)
    typer.echo(f"Processed {input_file} into {output_file or input_file + '.processed'}")

if __name__ == "__main__":
    app()
