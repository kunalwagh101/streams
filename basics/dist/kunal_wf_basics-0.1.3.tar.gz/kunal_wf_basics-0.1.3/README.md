python -m kunal_wf_basics.commands
pip install --index-url https://test.pypi.org/simple/ kunal-wf-basics

kunal_wf_basics "input" 